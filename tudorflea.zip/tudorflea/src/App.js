import React from 'react';
import logo from './parsaflea.png';
import './App.css';



class knockoff extends React.Component {
  render() {
    return (
      <div className="shopping-list">
        <h1>Tudorflea {this.props.name}</h1>
        <br></br>
        <br></br>
        <br></br>
        <img src={logo} className="App-logo" alt="logo" />
        <br></br>
        <br></br>
        <br></br>
        <br></br>
        <ul>
          <li>cat</li>
          <li>er</li>
          <li>pillar</li>
        </ul>
        <br></br>

      </div>
    );
  }
}

export default knockoff;



// function app() {
//   return (
//     <div className="App">
//       <header className="App-header">
//         {/* <img src={} className="App-logo" alt="logo" /> */}
//         <p>
//           {/* Edit <code>src/App.js</code> and save to reload. */}
//         </p>
//         <a
//           // className="App-link"
//           // href="https://reactjs.org"
//           // target="_blank"
//           // rel="noopener noreferrer"
//         >
//           {/* Learn React */}
//         </a>
//       </header>
//     </div>
//   );
// }

// export default app;
